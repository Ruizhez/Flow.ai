//
//  InternalFlow_Watch_InternalFlow_Watch_InternalFlow_Watch_InternalFlow_WatchApp.swift
//  InternalFlow Watch InternalFlow Watch InternalFlow Watch InternalFlow Watch Watch App
//
//  Created by Ruizhe Zheng on 4/25/25.
//

import SwiftUI

@main
struct InternalFlow_Watch_InternalFlow_Watch_InternalFlow_Watch_InternalFlow_Watch_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
