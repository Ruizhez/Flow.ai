//
//  InternalFlow_iphone_appTests.swift
//  InternalFlow iphone appTests
//
//  Created by Ruizhe Zheng on 4/26/25.
//

import Testing
@testable import InternalFlow_iphone_app

struct InternalFlow_iphone_appTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
